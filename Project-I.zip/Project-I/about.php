<?php include 'header.php';?>


<!-- Content -->
<div id="content">

    <!-- Intro -->
    <section class="p-t-b-150">
        <div class="container">
            <div class="intro-main">
                <div class="row">

                    <!-- Intro Detail -->
                    <div class="col-md-7">
                        <div class="text-sec padding-right-0">
                            <h5>Our Vision</h5>
                            <p>For the next phase of development the vision is to ‘Touch a Million Lives’.</p>
                            <h5 class="margin-top-25">Our Mission</h5>
                            <p>“Our mission is to bring healthcare of International standards within the reach of every individual in India. We are committed to the achievement and maintenance of excellence in education, research and healthcare for the benefit of humanity”.</p>
                            <h6 class="margin-top-25"> <i class="lnr  lnr-checkmark-circle" ></i><font size="+2"> About City Hospital</font></h6>
                            <p class="margin-top-25">The cornerstones of City Hospital’s legacy are its unstinting focus on clinical excellence, affordable costs, modern technology and forward-looking research & academics. City Hospitals was among the first few hospitals in the world to leverage technology to facilitate seamless healthcare delivery. The organization embraced the rapid advancement in medical equipments across the world, and pioneered the introduction of several cutting edge innovations in India. Recently, South East Asia’s first Proton Therapy Centre commenced operations at the City Centre in Chandigarh. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


</div>

<!-- Footer -->
<!--======= FOOTER =========-->

<?php include 'footer.php';?>